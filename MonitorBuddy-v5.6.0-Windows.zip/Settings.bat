@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0MonitorBuddySettings.exe"
endlocal
