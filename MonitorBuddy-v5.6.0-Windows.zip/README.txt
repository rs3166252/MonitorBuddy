﻿MONITOR BUDDY v5.0
Portable Release

Start:
  Start Monitor Buddy.bat
  or MonitorBuddy.exe

Settings:
  Settings.bat
  or MonitorBuddySettings.exe

If ControlMyMonitor.exe is not already in bin\, Monitor Buddy starts the
included Setup flow. Setup can automatically download the official
ControlMyMonitor ZIP or let the user select the official EXE/ZIP manually.

The Release folder intentionally contains the small src\ runtime scripts
needed by the dependency/setup fallback. No development build scripts or
development logs are included.
