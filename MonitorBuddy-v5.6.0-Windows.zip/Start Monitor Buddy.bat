@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0MonitorBuddy.exe"
endlocal
