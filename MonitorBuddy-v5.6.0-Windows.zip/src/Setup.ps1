
# Monitor Buddy v2.5 Setup
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$Root=Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$CfgDir=Join-Path $Root 'config'
$Cfg=Join-Path $CfgDir 'config.json'
$Cmm=Join-Path $Root 'bin\ControlMyMonitor.exe'
$Icon=Join-Path $Root 'assets\MonitorBuddy.ico'

New-Item -ItemType Directory -Path $CfgDir -Force | Out-Null

function Set-Status([string]$text,[int]$value=-1){
    $script:status.Text=$text
    if($value -ge 0){$script:progress.Value=[Math]::Min(100,$value)}
    [Windows.Forms.Application]::DoEvents()
}
function Show-Error([string]$msg){
    [Windows.Forms.MessageBox]::Show($msg,'Monitor Buddy','OK','Error')|Out-Null
}

$f=New-Object Windows.Forms.Form
$f.Text='Monitor Buddy'
$f.Size=New-Object Drawing.Size(960,680)
$f.StartPosition='CenterScreen'
$f.FormBorderStyle='FixedDialog'
$f.MaximizeBox=$false
$f.BackColor=[Drawing.Color]::FromArgb(246,248,251)
$f.Font=New-Object Drawing.Font('Segoe UI',9)

$header=New-Object Windows.Forms.Panel
$header.Dock='Top';$header.Height=92;$header.BackColor=[Drawing.Color]::FromArgb(24,91,171)
$f.Controls.Add($header)

$logo=New-Object Windows.Forms.PictureBox
$logo.Location=New-Object Drawing.Point(20,18);$logo.Size=New-Object Drawing.Size(56,56);$logo.SizeMode='Zoom'
if(Test-Path $Icon){try{$logo.Image=[Drawing.Image]::FromFile($Icon)}catch{}}
$header.Controls.Add($logo)

$brand=New-Object Windows.Forms.Label
$brand.Text='Monitor Buddy';$brand.ForeColor=[Drawing.Color]::White
$brand.Font=New-Object Drawing.Font('Segoe UI Semibold',18,[Drawing.FontStyle]::Bold)
$brand.AutoSize=$true;$brand.Location=New-Object Drawing.Point(88,17);$header.Controls.Add($brand)

$sub=New-Object Windows.Forms.Label
$sub.Text='Universal monitor input switcher';$sub.ForeColor=[Drawing.Color]::FromArgb(220,235,255)
$sub.AutoSize=$true;$sub.Location=New-Object Drawing.Point(90,50);$header.Controls.Add($sub)

$step=New-Object Windows.Forms.Label
$step.Text='SETUP';$step.ForeColor=[Drawing.Color]::White
$step.Font=New-Object Drawing.Font('Segoe UI Semibold',9,[Drawing.FontStyle]::Bold)
$step.AutoSize=$true;$step.Location=New-Object Drawing.Point(865,38);$header.Controls.Add($step)

$title=New-Object Windows.Forms.Label
$title.Text='Preparing Monitor Buddy'
$title.Font=New-Object Drawing.Font('Segoe UI Semibold',15,[Drawing.FontStyle]::Bold)
$title.ForeColor=[Drawing.Color]::FromArgb(32,39,48);$title.AutoSize=$true
$title.Location=New-Object Drawing.Point(34,118);$f.Controls.Add($title)

$desc=New-Object Windows.Forms.Label
$desc.Text='Setup checks the dependency, detects your monitors, and prepares input shortcuts.'
$desc.ForeColor=[Drawing.Color]::FromArgb(90,99,110);$desc.AutoSize=$true
$desc.Location=New-Object Drawing.Point(35,149);$f.Controls.Add($desc)

$card=New-Object Windows.Forms.Panel
$card.Location=New-Object Drawing.Point(28,185);$card.Size=New-Object Drawing.Size(890,300)
$card.BackColor=[Drawing.Color]::White;$card.BorderStyle='FixedSingle';$f.Controls.Add($card)

$status=New-Object Windows.Forms.Label
$status.Text='Starting...';$status.Font=New-Object Drawing.Font('Segoe UI Semibold',11)
$status.ForeColor=[Drawing.Color]::FromArgb(32,39,48);$status.AutoSize=$true
$status.Location=New-Object Drawing.Point(24,24);$card.Controls.Add($status)
$script:status=$status

$details=New-Object Windows.Forms.Label
$details.Text='';$details.ForeColor=[Drawing.Color]::FromArgb(100,108,118)
$details.AutoSize=$true;$details.Location=New-Object Drawing.Point(24,58);$card.Controls.Add($details)
$script:details=$details

$progress=New-Object Windows.Forms.ProgressBar
$progress.Location=New-Object Drawing.Point(24,100);$progress.Size=New-Object Drawing.Size(842,22)
$progress.Minimum=0;$progress.Maximum=100;$progress.Value=0
$card.Controls.Add($progress);$script:progress=$progress

$results=New-Object Windows.Forms.ListView
$results.Location=New-Object Drawing.Point(24,140);$results.Size=New-Object Drawing.Size(842,130)
$results.View='Details';$results.FullRowSelect=$true;$results.GridLines=$true
[void]$results.Columns.Add('Monitor',270);[void]$results.Columns.Add('Display',160);[void]$results.Columns.Add('DDC/CI',120);[void]$results.Columns.Add('Status',260)
$card.Controls.Add($results)

$hint=New-Object Windows.Forms.Label
$hint.Text='ControlMyMonitor is used only for DDC/CI monitor control. If automatic setup cannot obtain it, you can select the official EXE manually.'
$hint.ForeColor=[Drawing.Color]::FromArgb(105,114,124);$hint.AutoSize=$true
$hint.Location=New-Object Drawing.Point(35,510);$f.Controls.Add($hint)

$back=New-Object Windows.Forms.Button
$back.Text='Back';$back.Enabled=$false;$back.Size=New-Object Drawing.Size(105,40)
$back.Location=New-Object Drawing.Point(690,555);$f.Controls.Add($back)

$next=New-Object Windows.Forms.Button
$next.Text='Continue';$next.Enabled=$false;$next.BackColor=[Drawing.Color]::FromArgb(24,91,171)
$next.ForeColor=[Drawing.Color]::White;$next.FlatStyle='Flat'
$next.Size=New-Object Drawing.Size(145,40);$next.Location=New-Object Drawing.Point(775,555)
$f.Controls.Add($next)

$script:found=$null
$script:selected=$null
$script:monitorInfo=$null


function Find-Cmm {
    if(Test-Path -LiteralPath $Cmm){ return $Cmm }
    return $null
}

function Download-OfficialControlMyMonitor {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem

    $url='https://www.nirsoft.net/utils/controlmymonitor.zip'
    $download=Join-Path $env:TEMP 'MonitorBuddy-ControlMyMonitor.zip'
    $extract=Join-Path $env:TEMP ('MonitorBuddy-CMM-'+[guid]::NewGuid().ToString())

    try {
        Set-Status 'Downloading ControlMyMonitor from NirSoft...' 8
        $script:details.Text='Downloading the official ControlMyMonitor ZIP.'
        [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $url -OutFile $download -UseBasicParsing -TimeoutSec 45

        if(-not (Test-Path -LiteralPath $download)){ throw 'Download did not produce a file.' }

        Set-Status 'Extracting ControlMyMonitor...' 12
        New-Item -ItemType Directory -Path $extract -Force | Out-Null
        [IO.Compression.ZipFile]::ExtractToDirectory($download,$extract)

        $exe=Get-ChildItem -LiteralPath $extract -Filter 'ControlMyMonitor.exe' -File -Recurse |
             Select-Object -First 1
        if($null -eq $exe){ throw 'ControlMyMonitor.exe was not found in the downloaded ZIP.' }

        New-Item -ItemType Directory -Path (Split-Path $Cmm) -Force | Out-Null
        Copy-Item -LiteralPath $exe.FullName -Destination $Cmm -Force

        # Keep the dependency unmodified. The original ZIP is not bundled into
        # Monitor Buddy; only the official executable is copied to bin.
        Set-Status 'ControlMyMonitor ready.' 15
        $script:details.Text='Official ControlMyMonitor downloaded and prepared.'
        return $true
    }
    catch {
        $script:details.Text='Automatic download failed: '+$_.Exception.Message
        return $false
    }
    finally {
        Remove-Item -LiteralPath $download -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $extract -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Install-SelectedControlMyMonitor {
    param([string]$SelectedPath)

    try {
        $ext=[IO.Path]::GetExtension($SelectedPath).ToLowerInvariant()
        New-Item -ItemType Directory -Path (Split-Path $Cmm) -Force | Out-Null

        if($ext -eq '.exe'){
            if([IO.Path]::GetFileName($SelectedPath) -ne 'ControlMyMonitor.exe'){
                throw 'Please select the official ControlMyMonitor.exe file.'
            }
            Copy-Item -LiteralPath $SelectedPath -Destination $Cmm -Force
        }
        elseif($ext -eq '.zip'){
            $tmp=Join-Path $env:TEMP ('MonitorBuddy-CMM-'+[guid]::NewGuid().ToString())
            New-Item -ItemType Directory -Path $tmp -Force | Out-Null
            Expand-Archive -LiteralPath $SelectedPath -DestinationPath $tmp -Force
            $exe=Get-ChildItem -LiteralPath $tmp -Filter 'ControlMyMonitor.exe' -File -Recurse | Select-Object -First 1
            if($null -eq $exe){ throw 'ControlMyMonitor.exe was not found inside the selected ZIP.' }
            Copy-Item -LiteralPath $exe.FullName -Destination $Cmm -Force
            Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        }
        else {
            throw 'Please select ControlMyMonitor.exe or the ControlMyMonitor ZIP.'
        }

        if(-not (Test-Path $Cmm)){ throw 'ControlMyMonitor could not be copied.' }
        return $true
    }
    catch {
        Show-Error ("Monitor Buddy could not use the selected file.`n`n{0}" -f $_.Exception.Message)
        return $false
    }
}

function Select-ControlMyMonitorFile {
    $dlg=New-Object Windows.Forms.OpenFileDialog
    $dlg.Title='Select ControlMyMonitor'
    $dlg.Filter='ControlMyMonitor files|ControlMyMonitor.exe;controlmymonitor*.zip|ControlMyMonitor.exe|ControlMyMonitor.exe|ControlMyMonitor ZIP|controlmymonitor*.zip|All files (*.*)|*.*'
    $dlg.CheckFileExists=$true

    if($dlg.ShowDialog() -eq 'OK'){
        return (Install-SelectedControlMyMonitor -SelectedPath $dlg.FileName)
    }
    return $false
}

function Show-DependencyFallback {
    # Simple two-step flow:
    # YES = user already has the EXE or ZIP -> select it now.
    # NO  = open official NirSoft page -> after download, select EXE or ZIP.
    $answer=[Windows.Forms.MessageBox]::Show(
        "ControlMyMonitor could not be downloaded automatically.`n`nDo you already have the ControlMyMonitor EXE or ZIP?`n`nYes = select the file now`nNo = open the official NirSoft download page",
        'Monitor Buddy','YesNo','Question')

    if($answer -eq 'Yes'){
        return (Select-ControlMyMonitorFile)
    }

    # User does not have it: open the official page first.
    Start-Process 'https://www.nirsoft.net/utils/control_my_monitor.html'

    # After the browser opens, immediately give the user the same selector.
    # They can download/extract in the browser and then select either EXE or ZIP.
    [Windows.Forms.MessageBox]::Show(
        "The official NirSoft page is now open.`n`nDownload ControlMyMonitor, then click OK to select the EXE or ZIP file.",
        'Monitor Buddy','OK','Information') | Out-Null

    return (Select-ControlMyMonitorFile)
}

function Discover-Monitors {
    Set-Status 'Scanning display devices...' 25
    $script:details.Text='Asking ControlMyMonitor for the connected monitor list.'
    $results.Items.Clear()
    $list=@()

    $tmp=Join-Path $env:TEMP ("MonitorBuddy_"+[guid]::NewGuid().ToString()+'.txt')
    try {
        Set-Status 'Reading monitor information...' 45
        & $Cmm /smonitors $tmp | Out-Null

        if(Test-Path -LiteralPath $tmp){
            $text=Get-Content -LiteralPath $tmp -Raw
            # /smonitors is a simple text export. Split monitor blocks and
            # capture the fields documented by NirSoft.
            $blocks=[regex]::Split($text.Trim(),"(?m)(?=Monitor Device Name:\s*)")
            foreach($b in $blocks){
                if($b -notmatch 'Monitor Device Name:'){ continue }
                $dev=([regex]::Match($b,'Monitor Device Name:\s*"?([^"\r\n]+)"?')).Groups[1].Value.Trim()
                $name=([regex]::Match($b,'Monitor Name:\s*"?([^"\r\n]+)"?')).Groups[1].Value.Trim()
                $serial=([regex]::Match($b,'Serial Number:\s*"?([^"\r\n]+)"?')).Groups[1].Value.Trim()
                $short=([regex]::Match($b,'Short Monitor ID:\s*([^\r\n]+)')).Groups[1].Value.Trim()
                if([string]::IsNullOrWhiteSpace($name)){$name=$short}
                if(-not [string]::IsNullOrWhiteSpace($dev)){
                    $list += [pscustomobject]@{
                        Name=$name;Device=$dev;Short=$short;Serial=$serial
                    }
                }
            }
        }
    } catch {
        $script:details.Text='Monitor scan failed: '+$_.Exception.Message
    }
    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue

    if($list.Count -eq 0){
        Set-Status 'No DDC/CI monitor found.' 100
        $script:details.Text='No monitor was returned by ControlMyMonitor. Check the cable and DDC/CI setting.'
        return
    }

    Set-Status 'Monitors detected.' 80
    foreach($m in $list){
        $item=New-Object Windows.Forms.ListViewItem($m.Name)
        [void]$item.SubItems.Add($m.Device)
        [void]$item.SubItems.Add('Detected')
        [void]$item.SubItems.Add('Ready to configure')
        $item.Tag=$m
        [void]$results.Items.Add($item)
    }
    $results.Items[0].Selected=$true
    $script:found=$list
    $script:selected=$list[0]
    Set-Status 'Monitor scan complete.' 100
    $script:details.Text="$($list.Count) monitor(s) detected. Select one and continue."
    $next.Enabled=$true
}

$next.Add_Click({
    if($null -eq $script:selected){
        if($results.SelectedItems.Count -gt 0){$script:selected=$results.SelectedItems[0].Tag}
    }
    if($null -eq $script:selected){return}

    # Build the same configuration shape used by the stable engine.
    $target=$script:selected
    $monitorString=$target.Short
    if([string]::IsNullOrWhiteSpace($monitorString)){ $monitorString=$target.Name }

    $inputs=@(
        [ordered]@{Value=15;Name='DisplayPort';Hotkey='Ctrl + Alt + Shift + F1'},
        [ordered]@{Value=17;Name='HDMI-1';Hotkey='Ctrl + Alt + Shift + F2'}
    )

    $json=[ordered]@{
        Version=1
        Monitor=[ordered]@{
            String=([string]$monitorString).Trim().Trim('"')
            Name=[string]$target.Name
            Device=[string]$target.Device
            Serial=[string]$target.Serial
            ShortID=([string]$monitorString).Trim().Trim('"')
        }
        VCP=60
        Inputs=$inputs
    }

    $json | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $Cfg -Encoding UTF8
    [void](Create-DesktopShortcut)
    Set-Status 'Configuration saved.' 100
    $script:details.Text='Monitor Buddy is ready to start.'
    $next.Text='Start Monitor Buddy'
    $next.Enabled=$true
    $next.Tag='complete'
    # Completed state: start the compiled application directly when this is
    # a v5 release. Keep the BAT/source fallback for source-build testing.
    $next.Add_Click({
        try {
            $appExe=Join-Path $Root 'MonitorBuddy.exe'
            if(Test-Path -LiteralPath $appExe){
                Start-Process -FilePath $appExe -WorkingDirectory $Root | Out-Null
            } else {
                Start-Process -FilePath (Join-Path $Root 'Start-MonitorBuddy.bat') -WorkingDirectory $Root | Out-Null
            }
        } catch {}
        $f.Close()
    })

    # Start the same application the user will run later. In a compiled v5
    # Release this must be MonitorBuddy.exe, not a second PowerShell host.
    try {
        $appExe=Join-Path $Root 'MonitorBuddy.exe'
        if(Test-Path -LiteralPath $appExe){
            Start-Process -FilePath $appExe -WorkingDirectory $Root | Out-Null
        } else {
            Start-Process -FilePath (Join-Path $Root 'Start-MonitorBuddy.bat') -WorkingDirectory $Root | Out-Null
        }
        [Windows.Forms.MessageBox]::Show(('Setup complete.'+[Environment]::NewLine+[Environment]::NewLine+'Monitor Buddy has been started in the system tray.'+[Environment]::NewLine+[Environment]::NewLine+'Use the Desktop shortcut to start Monitor Buddy again later.'),'Monitor Buddy','OK','Information')|Out-Null
    } catch {
        [Windows.Forms.MessageBox]::Show(('Setup completed, but Monitor Buddy could not be started automatically.'+[Environment]::NewLine+[Environment]::NewLine+'Use the Desktop shortcut to start it.'),'Monitor Buddy','OK','Warning')|Out-Null
    }
    $f.Close()
})

$results.Add_SelectedIndexChanged({
    if($results.SelectedItems.Count -gt 0){$script:selected=$results.SelectedItems[0].Tag}
})


function Create-DesktopShortcut {
    try {
        $desktop=[Environment]::GetFolderPath('Desktop')
        $lnk=Join-Path $desktop 'Monitor Buddy.lnk'
        $ws=New-Object -ComObject WScript.Shell
        $sc=$ws.CreateShortcut($lnk)
        $sc.TargetPath=(Join-Path $Root 'Start-MonitorBuddy.bat')
        $sc.WorkingDirectory=$Root
        $sc.IconLocation="$Icon,0"
        $sc.Description='Monitor Buddy - Universal monitor input switcher'
        $sc.Save()
        return $true
    } catch { return $false }
}

$f.Add_Shown({
    Set-Status 'Checking ControlMyMonitor...' 5
    $script:details.Text='Checking the local dependency.'
    if(-not (Find-Cmm)){
        if(-not (Download-OfficialControlMyMonitor)){
            Set-Status 'Automatic download failed.' 12
            if(-not (Show-DependencyFallback)){
                $next.Enabled=$false
                return
            }
        }
    }
    Set-Status 'ControlMyMonitor ready.' 15
    Discover-Monitors
})

[void]$f.ShowDialog()

# This script is a dedicated GUI host; terminate it after the form closes.
[Environment]::Exit(0)
