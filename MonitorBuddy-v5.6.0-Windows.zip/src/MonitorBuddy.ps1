
# Monitor Buddy v1.3
$ErrorActionPreference='Stop'
# Resolve the application root in both normal .ps1 execution and PS2EXE builds.
$Root = if(-not [string]::IsNullOrWhiteSpace([string]$ScriptRoot)){
    [string]$ScriptRoot
} elseif(-not [string]::IsNullOrWhiteSpace([string]$PSScriptRoot)){
    [string]$PSScriptRoot
} else {
    Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
}
$ConfigFile = Join-Path $Root 'config\config.ini'
$JsonConfigFile = Join-Path $Root 'config\config.json'
$Cmm = Join-Path $Root 'bin\ControlMyMonitor.exe'
$IconFile = Join-Path $Root 'assets\MonitorBuddy.ico'
$LogDir = Join-Path $Root 'logs'
$LogFile = Join-Path $LogDir 'MonitorBuddy.log'
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

function Log([string]$s) {
    try { Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $s" } catch {}
}

Log 'START'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$WinFormsDll = [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms').Location
$DrawingDll = [System.Reflection.Assembly]::LoadWithPartialName('System.Drawing').Location

if (-not (Test-Path $Cmm)) {
    Log 'NO_CMM'
    Start-Process (Join-Path $Root 'Setup.bat') -WorkingDirectory $Root
    exit 3
}

$monitor=''
$monitorName=''
$inputs=@()

# JSON is the authoritative configuration.
if(Test-Path $JsonConfigFile){
    try {
        $cfg = Get-Content -LiteralPath $JsonConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $monitor = [string]$cfg.Monitor.String
        if([string]::IsNullOrWhiteSpace($monitor)){ $monitor=[string]$cfg.Monitor.Device }
        $monitorName=[string]$cfg.Monitor.Name
        foreach($i in @($cfg.Inputs)){
            if($null -ne $i -and -not [string]::IsNullOrWhiteSpace([string]$i.Value)){
                $inputs += [pscustomobject]@{
                    Id=$inputs.Count+1
                    Value=[int]$i.Value
                    Name=[string]$i.Name
                    Hotkey=[string]$i.Hotkey
                }
            }
        }
        Log ("JSON_CONFIG monitor='{0}' device='{1}' name='{2}' inputs={3}" -f $monitor,[string]$cfg.Monitor.Device,$monitorName,$inputs.Count)
    } catch {
        Log ("JSON_CONFIG_ERROR {0}" -f $_.Exception.Message)
    }
}

# Compatibility fallback for older Monitor Buddy installations.
if([string]::IsNullOrWhiteSpace($monitor) -or $inputs.Count -eq 0){
    if(Test-Path $ConfigFile){
        $ini=@{}
        foreach($line in Get-Content -LiteralPath $ConfigFile -ErrorAction SilentlyContinue) {
            if($line -match '^\s*([^#;=\[]+)\s*=\s*(.*?)\s*$'){
                $ini[$matches[1].Trim()]=$matches[2].Trim()
            }
        }
        $monitor=[string]$ini['MonitorString']
        if([string]::IsNullOrWhiteSpace($monitor)){ $monitor=[string]$ini['MonitorDeviceName'] }
        $monitorName=[string]$ini['MonitorName']
        $inputs=@()
        1..9 | ForEach-Object {
            $n=$_
            if($ini.ContainsKey("Input${n}Value") -and -not [string]::IsNullOrWhiteSpace([string]$ini["Input${n}Value"])){
                $inputs += [pscustomobject]@{
                    Id=$n
                    Value=[int]$ini["Input${n}Value"]
                    Name=[string]$ini["Input${n}Name"]
                    Hotkey=[string]$ini["Input${n}Hotkey"]
                }
            }
        }
        Log ("INI_CONFIG monitor='{0}' device='{1}' name='{2}' inputs={3}" -f $monitor,[string]$ini['MonitorDeviceName'],$monitorName,$inputs.Count)
    }
}

if([string]::IsNullOrWhiteSpace($monitor) -or $inputs.Count -eq 0) {
    Log 'BAD_CONFIG'
    Start-Process (Join-Path $Root 'Setup.bat') -WorkingDirectory $Root
    exit 2
}

# Prevent duplicate instances.
$mutex=New-Object System.Threading.Mutex($false,'Global\MonitorBuddyUniversal')
if(-not $mutex.WaitOne(0,$false)) {
    Log 'ALREADY_RUNNING'
    exit 0
}

try {
    # Microsoft-documented global hotkeys.
    # RegisterHotKey posts WM_HOTKEY to this hidden WinForms window.
    # The hotkey handler directly invokes the same ControlMyMonitor command
    # that Test-Input.bat already proved works.
    Add-Type -ReferencedAssemblies @($WinFormsDll,$DrawingDll) @"
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class MBHotkeyWindow : Form
{
    private const int WM_HOTKEY = 0x0312;
    private const uint MOD_ALT = 0x0001;
    private const uint MOD_CONTROL = 0x0002;
    private const uint MOD_SHIFT = 0x0004;
    private const uint MOD_NOREPEAT = 0x4000;

    [DllImport("user32.dll", SetLastError=true)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll", SetLastError=true)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    public string LastError { get; private set; }
    public string MonitorId { get; set; }
    public string ControlMyMonitorPath { get; set; }
    public int[] InputValues { get; private set; }
    public string LogPath { get; set; }

    public MBHotkeyWindow()
    {
        InputValues = new int[10];
        ShowInTaskbar = false;
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        Location = new System.Drawing.Point(-32000, -32000);
        Size = new System.Drawing.Size(1, 1);
        Opacity = 0;
        Text = "Monitor Buddy Hotkey Host";
    }

    protected override void SetVisibleCore(bool value)
    {
        base.SetVisibleCore(false);
    }

    public bool RegisterInput(int id, int vk)
    {
        bool ok = RegisterHotKey(Handle, id, MOD_CONTROL | MOD_ALT | MOD_SHIFT | MOD_NOREPEAT, (uint)vk);
        if (!ok) LastError = Marshal.GetLastWin32Error().ToString();
        return ok;
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WM_HOTKEY)
        {
            int id = m.WParam.ToInt32();
            int value = (id >= 1 && id < InputValues.Length) ? InputValues[id] : 0;
            if (value != 0 && !String.IsNullOrWhiteSpace(MonitorId) &&
                !String.IsNullOrWhiteSpace(ControlMyMonitorPath))
            {
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = ControlMyMonitorPath;
                    psi.Arguments = String.Format("/SetValueIfNeeded \"{0}\" 60 {1}",
                        MonitorId.Replace("\"",""), value);
                    psi.UseShellExecute = false;
                    psi.CreateNoWindow = true;
                    Process.Start(psi);
                }
                catch { }
            }
        }
        base.WndProc(ref m);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            for(int id=1; id<InputValues.Length; id++)
            {
                try { UnregisterHotKey(Handle, id); } catch {}
            }
        }
        base.Dispose(disposing);
    }
}
"@


    $tray=New-Object Windows.Forms.NotifyIcon
    try {
        if(Test-Path $IconFile) { $tray.Icon=New-Object Drawing.Icon($IconFile) }
        else { $tray.Icon=[Drawing.SystemIcons]::Application }
    } catch { $tray.Icon=[Drawing.SystemIcons]::Application }

    $tray.Text=("Monitor Buddy - {0} - Running" -f $monitorName)
    $tray.Visible=$true
    Log 'TRAY_VISIBLE'
    Log 'HOTKEY_MODE CONFIGURABLE_F1_F9'
    $tray.ShowBalloonTip(1200,'Monitor Buddy',"Running on $monitorName",[Windows.Forms.ToolTipIcon]::Info)

    # Controlled tray popup: a borderless WinForms window rather than a
    # ContextMenuStrip. This gives Monitor Buddy exact control over size,
    # spacing and placement above the Windows taskbar.
    $menu=New-Object Windows.Forms.Form
    $menu.Name='MonitorBuddyTrayMenu'
    $menu.Text=''
    $menu.FormBorderStyle='None'
    $menu.ShowInTaskbar=$false
    $menu.StartPosition='Manual'
    $menu.TopMost=$true
    $menu.BackColor=[Drawing.Color]::White
    $menu.ClientSize=New-Object Drawing.Size(390,330)
    $menu.Padding=New-Object Windows.Forms.Padding(0)
    $menu.Font=New-Object Drawing.Font('Segoe UI',9)
    $menu.Add_Deactivate({ $menu.Hide() })

    # Direct popup layout: the branded header is attached directly to the
    # Form. No border/body wrapper is used, so the blue background truly
    # reaches the popup's left and right edges.
    $brandPanel=New-Object Windows.Forms.Panel
    $brandPanel.Location=[System.Drawing.Point]::new(0,0)
    $brandPanel.Size=New-Object Drawing.Size(390,70)
    $brandPanel.BackColor=[Drawing.Color]::FromArgb(24,91,171)
    $menu.Controls.Add($brandPanel)

    $brandLogo=New-Object Windows.Forms.PictureBox
    $brandLogo.Location=[System.Drawing.Point]::new(10,8)
    $brandLogo.Size=New-Object Drawing.Size(54,54)
    $brandLogo.SizeMode='Zoom'
    $brandLogo.BackColor=[Drawing.Color]::Transparent
    try {
        if(Test-Path $IconFile) { $brandLogo.Image=[Drawing.Image]::FromFile($IconFile) }
    } catch {}
    $brandPanel.Controls.Add($brandLogo)

    $brandMonitor=New-Object Windows.Forms.Label
    $brandMonitor.Text=$monitorName
    $brandMonitor.Location=[System.Drawing.Point]::new(76,10)
    $brandMonitor.Size=New-Object Drawing.Size(282,25)
    $brandMonitor.Font=New-Object Drawing.Font('Segoe UI Semibold',10.5,[Drawing.FontStyle]::Bold)
    $brandMonitor.ForeColor=[Drawing.Color]::White
    $brandMonitor.TextAlign=[Drawing.ContentAlignment]::MiddleLeft
    $brandPanel.Controls.Add($brandMonitor)

    $brandStatus=New-Object Windows.Forms.Label
    $brandStatus.Text=('ACTIVE  |  DDC/CI  |  {0} input(s)' -f $inputs.Count)
    $brandStatus.Location=[System.Drawing.Point]::new(76,38)
    $brandStatus.Size=New-Object Drawing.Size(282,20)
    $brandStatus.Font=New-Object Drawing.Font('Segoe UI',8.5)
    $brandStatus.ForeColor=[Drawing.Color]::FromArgb(220,235,255)
    $brandStatus.TextAlign=[Drawing.ContentAlignment]::MiddleLeft
    $brandPanel.Controls.Add($brandStatus)

    $y=87

    foreach($inp in $inputs) {
        $item=New-Object Windows.Forms.Button
        $item.Text=("{0}    {1}" -f $inp.Name,$inp.Hotkey)
        $item.Tag=$inp
        $item.Location=[System.Drawing.Point]::new([int](8),[int]($y))
        $item.Size=New-Object Drawing.Size(372,32)
        $item.FlatStyle='Flat'
        $item.FlatAppearance.BorderSize=0
        $item.BackColor=[Drawing.Color]::White
        $item.ForeColor=[Drawing.Color]::FromArgb(25,31,38)
        $item.Font=New-Object Drawing.Font('Segoe UI',9)
        $item.TextAlign=[Drawing.ContentAlignment]::MiddleLeft
        $item.Padding=New-Object Windows.Forms.Padding(10,0,5,0)
        $menu.Controls.Add($item)
        $item.Add_Click({
            param($sender,$eventArgs)
            $c=$sender.Tag
            & $Cmm /SetValueIfNeeded $monitor 60 $c.Value | Out-Null
            $ec=$LASTEXITCODE
            Log ("MENU_SWITCH {0} VALUE={1} EXIT={2}" -f $c.Name,$c.Value,$ec)
            $tray.ShowBalloonTip(700,'Monitor Buddy',"Switched to $($c.Name)",[Windows.Forms.ToolTipIcon]::Info)
            $menu.Hide()
        })
        $y+=34
    }

    # separator
    $sep=New-Object Windows.Forms.Label
    $sep.Location=[System.Drawing.Point]::new([int](8),[int]($y+1))
    $sep.Size=New-Object Drawing.Size(372,1)
    $sep.BackColor=[Drawing.Color]::FromArgb(220,224,229)
    $menu.Controls.Add($sep)

    $status=New-Object Windows.Forms.Label
    $status.Text='Status: Starting...'
    $status.Location=[System.Drawing.Point]::new([int](18),[int]($y+8))
    $status.Size=New-Object Drawing.Size(352,25)
    $status.Font=New-Object Drawing.Font('Segoe UI',8.5)
    $status.ForeColor=[Drawing.Color]::FromArgb(100,108,118)
    $status.TextAlign=[Drawing.ContentAlignment]::MiddleLeft
    $menu.Controls.Add($status)
    $y+=39

    $sep2=New-Object Windows.Forms.Label
    $sep2.Location=[System.Drawing.Point]::new([int](8),[int]($y))
    $sep2.Size=New-Object Drawing.Size(372,1)
    $sep2.BackColor=[Drawing.Color]::FromArgb(220,224,229)
    $menu.Controls.Add($sep2)
    $y+=8

    function New-TrayActionButton([string]$Text,[int]$Y) {
        $b=New-Object Windows.Forms.Button
        $b.Text=$Text
        $b.Location=[System.Drawing.Point]::new([int](8),[int]($Y))
        $b.Size=New-Object Drawing.Size(372,30)
        $b.FlatStyle='Flat'
        $b.FlatAppearance.BorderSize=0
        $b.BackColor=[Drawing.Color]::White
        $b.ForeColor=[Drawing.Color]::FromArgb(25,31,38)
        $b.Font=New-Object Drawing.Font('Segoe UI',9)
        $b.TextAlign=[Drawing.ContentAlignment]::MiddleLeft
        $b.Padding=New-Object Windows.Forms.Padding(10,0,5,0)
        $menu.Controls.Add($b)
        return $b
    }

    $settings=New-TrayActionButton 'Settings' $y
    $settings.Add_Click({
        $menu.Hide()
        try {
            $settingsExe=Join-Path $Root 'MonitorBuddySettings.exe'
            if(Test-Path -LiteralPath $settingsExe){
                Start-Process -FilePath $settingsExe -WorkingDirectory $Root | Out-Null
            } else {
                $settingsScript=Join-Path $Root 'src\Settings.ps1'
                $psi=New-Object System.Diagnostics.ProcessStartInfo
                $psi.FileName=(Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
                $psi.Arguments='-NoProfile -STA -ExecutionPolicy Bypass -File "'+$settingsScript+'"'
                $psi.WorkingDirectory=$Root
                $psi.UseShellExecute=$false
                [System.Diagnostics.Process]::Start($psi) | Out-Null
            }
            Log 'SETTINGS_LAUNCHED'
        } catch {
            Log ("SETTINGS_LAUNCH_ERROR {0}" -f $_.Exception.Message)
            [Windows.Forms.MessageBox]::Show(
                ("Could not open Settings.`n`n{0}" -f $_.Exception.Message),
                'Monitor Buddy','OK','Error'
            ) | Out-Null
        }
    })
    $y+=31

    $about=New-TrayActionButton 'About Monitor Buddy' $y
    $about.Add_Click({
        $menu.Hide()
        [Windows.Forms.MessageBox]::Show(
            "Monitor Buddy`n`n$monitorName`n`nUniversal DDC/CI input switcher.",
            'Monitor Buddy','OK','Information'
        ) | Out-Null
    })
    $y+=31

    $sep3=New-Object Windows.Forms.Label
    $sep3.Location=[System.Drawing.Point]::new([int](8),[int]($y))
    $sep3.Size=New-Object Drawing.Size(372,1)
    $sep3.BackColor=[Drawing.Color]::FromArgb(220,224,229)
    $menu.Controls.Add($sep3)
    $y+=8

    $exit=New-TrayActionButton 'Exit' $y
    $exit.Add_Click({ $menu.Hide(); [Windows.Forms.Application]::Exit() })

    # Size exactly to content. This is intentionally a Form, so the popup
    # cannot be clipped by ContextMenuStrip/taskbar placement.
    $menu.ClientSize=New-Object Drawing.Size(390,($y+40))

    $tray.Add_MouseClick({
        param($sender,$eventArgs)
        if($eventArgs.Button -eq [Windows.Forms.MouseButtons]::Left){
            try {
                $pt=[Windows.Forms.Cursor]::Position
                $screen=[Windows.Forms.Screen]::FromPoint($pt)
                $workArea=$screen.WorkingArea
                $w=$menu.Width
                $h=$menu.Height
                $x=$pt.X-[int]($w/2)
                $x=[Math]::Max($workArea.Left,[Math]::Min($x,$workArea.Right-$w))
                $yPos=$pt.Y-$h-8
                if($yPos -lt $workArea.Top){$yPos=$pt.Y+8}
                if($yPos+$h -gt $workArea.Bottom){$yPos=$workArea.Bottom-$h}
                $menu.Location=[System.Drawing.Point]::new([int]$x,[int]$yPos)
                $menu.Show()
                $menu.Activate()
                Log 'TRAY_MENU_LEFT_CLICK'
            } catch {
                Log ("TRAY_MENU_ERROR {0}" -f $_.Exception.Message)
            }
        }
    })

    # Settings writes this marker when it needs the running tray instance to
    # restart. A short timer keeps the tray process responsive.
    $restartFlag=Join-Path $Root 'config\restart.flag'
    $restartTimer=New-Object Windows.Forms.Timer
    $restartTimer.Interval=500
    $restartTimer.Add_Tick({
        if(Test-Path -LiteralPath $restartFlag){
            try { Remove-Item -LiteralPath $restartFlag -Force -ErrorAction SilentlyContinue } catch {}
            Log 'RESTART_REQUESTED'
            [Windows.Forms.Application]::Exit()
        }
    })

    $restartTimer.Start()

    $tray.Add_MouseDoubleClick({
        param($sender,$e)
        if($e.Button -eq [Windows.Forms.MouseButtons]::Left) {
            $settingsExe=Join-Path $Root 'MonitorBuddySettings.exe'
            if(Test-Path -LiteralPath $settingsExe){
                Start-Process -FilePath $settingsExe -WorkingDirectory $Root | Out-Null
            } else {
                Start-Process powershell.exe -WindowStyle Hidden -WorkingDirectory $Root -ArgumentList @(
                    '-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'src\Settings.ps1')
                )
            }
        }
    })

    $hotkeys=New-Object MBHotkeyWindow
    $hotkeys.MonitorId=$monitor
    $hotkeys.ControlMyMonitorPath=$Cmm
    $hotkeys.LogPath=$LogFile

    $registered=0
    $fKeyMap=@{}
    for($idx=0;$idx -lt $inputs.Count;$idx++){
        $inp=$inputs[$idx]
        $id=$idx+1
        $m=[regex]::Match([string]$inp.Hotkey,'(?i)\bF([1-9])\b')
        if(-not $m.Success){ continue }
        $fnum=[int]$m.Groups[1].Value
        $vk=0x6F+$fnum
        $hotkeys.InputValues[$id]=[int]$inp.Value
        if($hotkeys.RegisterInput($id,$vk)){
            $registered++
            $fKeyMap[$fnum]=$true
            Log ("HOTKEY_REGISTERED id={0} Ctrl+Alt+Shift+F{1} VALUE={2}" -f $id,$fnum,$inp.Value)
        } else {
            Log ("HOTKEY_REGISTER_FAILED id={0} VK=F{1} WIN32ERROR={2}" -f $id,$fnum,$hotkeys.LastError)
        }
    }

    Log ("HOTKEYS_ACTIVE {0}/{1}" -f $registered,$inputs.Count)

    $status.Text="Status: Running - {0}/{1} shortcut(s) active" -f $registered,$inputs.Count
    $status.ForeColor=[Drawing.Color]::SeaGreen

    # This is the actual tray lifetime.
    $tray.ShowBalloonTip(1800,'Monitor Buddy',"Running - $($inputs.Count) shortcut(s) active.",[Windows.Forms.ToolTipIcon]::Info)
    Log 'MESSAGE_LOOP'
    [Windows.Forms.Application]::Run()
    Log 'MESSAGE_LOOP_END'

    try { $restartTimer.Stop() } catch {}
    try { $restartTimer.Dispose() } catch {}
    try { $hotkeys.Dispose() } catch {}
    $tray.Visible=$false
    $tray.Dispose()
}
catch {
    Log ("FATAL {0}" -f $_.Exception.ToString())
    try {
        [Windows.Forms.MessageBox]::Show(
            "Monitor Buddy could not start.`n`nCheck:`n$LogFile`n`nError: $($_.Exception.Message)",
            'Monitor Buddy','OK','Error'
        ) | Out-Null
    } catch {}
    exit 1
}
finally {
    try { $mutex.ReleaseMutex() | Out-Null } catch {}
    try { $mutex.Dispose() } catch {}
}

# Hard-stop the dedicated Monitor Buddy host after all WinForms/DDC resources are released.
[Environment]::Exit(0)
