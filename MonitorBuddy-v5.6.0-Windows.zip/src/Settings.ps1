$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Resolve the application root in both normal .ps1 execution and PS2EXE builds.
$Root=if(-not [string]::IsNullOrWhiteSpace([string]$ScriptRoot)){
    [string]$ScriptRoot
} elseif(-not [string]::IsNullOrWhiteSpace([string]$PSScriptRoot)){
    [string]$PSScriptRoot
} else {
    Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
}
$Cfg=Join-Path $Root 'config\config.json'
$ProfilesFile=Join-Path $Root 'config\profiles.json'
$Cmm=Join-Path $Root 'bin\ControlMyMonitor.exe'
$Icon=Join-Path $Root 'assets\MonitorBuddy.ico'

function Msg($m,$title='Monitor Buddy',$icon='Information'){
    [Windows.Forms.MessageBox]::Show($m,$title,'OK',$icon)|Out-Null
}
function Save-Json($obj,$path){
    $obj | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $path -Encoding UTF8
}
function KeyForMonitor($m){
    $id=[string]$m.Short
    if([string]::IsNullOrWhiteSpace($id)){ $id=[string]$m.Serial }
    if([string]::IsNullOrWhiteSpace($id)){ $id=[string]$m.Device }
    return $id.Trim().Trim('"')
}

if(-not (Test-Path $Cmm)){ Start-Process (Join-Path $Root 'Setup.bat'); exit }
try { $cfg=Get-Content -LiteralPath $Cfg -Raw -Encoding UTF8 | ConvertFrom-Json } catch { Start-Process (Join-Path $Root 'Setup.bat'); exit }
try { $profiles=Get-Content -LiteralPath $ProfilesFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch {
    $profiles=[pscustomobject]@{Version=1;Profiles=@()}
}

# --- UI ---
$f=New-Object Windows.Forms.Form
$f.Text='Monitor Buddy - Settings'
$f.Size=New-Object Drawing.Size(940,700)
$f.MinimumSize=New-Object Drawing.Size(940,700)
$f.StartPosition='CenterScreen'
$f.FormBorderStyle='FixedDialog'
$f.MaximizeBox=$false
$f.BackColor=[Drawing.Color]::FromArgb(245,247,250)
$f.Font=New-Object Drawing.Font('Segoe UI',9)

# Brand header
$header=New-Object Windows.Forms.Panel
$header.Dock='Top';$header.Height=96
$header.BackColor=[Drawing.Color]::FromArgb(24,91,171)
$f.Controls.Add($header)

$logo=New-Object Windows.Forms.PictureBox
$logo.Location=New-Object Drawing.Point(22,18);$logo.Size=New-Object Drawing.Size(60,60)
$logo.SizeMode='Zoom';$logo.BackColor=[Drawing.Color]::Transparent
if(Test-Path $Icon){try{$logo.Image=[Drawing.Image]::FromFile($Icon)}catch{}}
$header.Controls.Add($logo)

$brand=New-Object Windows.Forms.Label
$brand.Text='Monitor Buddy'
$brand.ForeColor=[Drawing.Color]::White
$brand.Font=New-Object Drawing.Font('Segoe UI Semibold',20,[Drawing.FontStyle]::Bold)
$brand.AutoSize=$true;$brand.Location=New-Object Drawing.Point(96,18)
$header.Controls.Add($brand)

$tag=New-Object Windows.Forms.Label
$tag.Text='Universal monitor control'
$tag.ForeColor=[Drawing.Color]::FromArgb(220,235,255)
$tag.Font=New-Object Drawing.Font('Segoe UI',9)
$tag.AutoSize=$true;$tag.Location=New-Object Drawing.Point(99,54)
$header.Controls.Add($tag)

# Section title
$l=New-Object Windows.Forms.Label
$l.Text='Monitor Profile'
$l.Font=New-Object Drawing.Font('Segoe UI Semibold',12,[Drawing.FontStyle]::Bold)
$l.ForeColor=[Drawing.Color]::FromArgb(35,42,50)
$l.AutoSize=$true;$l.Location=New-Object Drawing.Point(32,116)
$f.Controls.Add($l)

$profileDesc=New-Object Windows.Forms.Label
$profileDesc.Text='Choose which connected monitor Monitor Buddy controls.'
$profileDesc.ForeColor=[Drawing.Color]::FromArgb(100,108,118)
$profileDesc.AutoSize=$true;$profileDesc.Location=New-Object Drawing.Point(32,143)
$f.Controls.Add($profileDesc)

$mon=New-Object Windows.Forms.ComboBox
$mon.Location=New-Object Drawing.Point(32,171);$mon.Size=New-Object Drawing.Size(700,34)
$mon.DropDownStyle='DropDownList';$mon.FlatStyle='Flat'
$f.Controls.Add($mon)

$refresh=New-Object Windows.Forms.Button
$refresh.Text='Refresh';$refresh.Location=New-Object Drawing.Point(746,171);$refresh.Size=New-Object Drawing.Size(126,34)
$refresh.FlatStyle='Flat';$refresh.BackColor=[Drawing.Color]::White
$f.Controls.Add($refresh)

# Status card
$statusPanel=New-Object Windows.Forms.Panel
$statusPanel.Location=New-Object Drawing.Point(32,222);$statusPanel.Size=New-Object Drawing.Size(840,58)
$statusPanel.BackColor=[Drawing.Color]::White
$f.Controls.Add($statusPanel)

# Encoding-safe profile status indicator: a real colored panel instead
# of a Unicode bullet, so legacy Windows PowerShell code pages cannot
# turn the indicator into mojibake such as â—□.
$statusDot=New-Object Windows.Forms.Panel
$statusDot.Size=New-Object Drawing.Size(8,8)
$statusDot.Location=New-Object Drawing.Point(16,25)
$statusDot.BackColor=[Drawing.Color]::SeaGreen
$statusPanel.Controls.Add($statusDot)

$profileInfo=New-Object Windows.Forms.Label
$profileInfo.Text='Select a monitor to load its saved profile.'
$profileInfo.ForeColor=[Drawing.Color]::FromArgb(75,83,92)
$profileInfo.AutoSize=$true;$profileInfo.Location=New-Object Drawing.Point(34,20)
$statusPanel.Controls.Add($profileInfo)

# Input section
$inputTitle=New-Object Windows.Forms.Label
$inputTitle.Text='Input & Shortcut Map'
$inputTitle.Font=New-Object Drawing.Font('Segoe UI Semibold',12,[Drawing.FontStyle]::Bold)
$inputTitle.ForeColor=[Drawing.Color]::FromArgb(35,42,50)
$inputTitle.AutoSize=$true;$inputTitle.Location=New-Object Drawing.Point(32,303)
$f.Controls.Add($inputTitle)

$inputDesc=New-Object Windows.Forms.Label
$inputDesc.Text='Each input has its own DDC/CI value and keyboard shortcut.'
$inputDesc.ForeColor=[Drawing.Color]::FromArgb(100,108,118)
$inputDesc.AutoSize=$true;$inputDesc.Location=New-Object Drawing.Point(32,330)
$f.Controls.Add($inputDesc)

$table=New-Object Windows.Forms.DataGridView
$table.Location=New-Object Drawing.Point(32,358);$table.Size=New-Object Drawing.Size(840,190)
$table.AllowUserToAddRows=$false;$table.AllowUserToDeleteRows=$false
$table.RowHeadersVisible=$false;$table.AutoSizeColumnsMode='Fill'
$table.BackgroundColor=[Drawing.Color]::White
$table.BorderStyle='FixedSingle'
$table.EnableHeadersVisualStyles=$false
$table.ColumnHeadersDefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(235,239,244)
$table.ColumnHeadersDefaultCellStyle.ForeColor=[Drawing.Color]::FromArgb(45,52,60)
$table.ColumnHeadersDefaultCellStyle.Font=New-Object Drawing.Font('Segoe UI Semibold',9)
[void]$table.Columns.Add('Value','VCP 60 Value')
[void]$table.Columns.Add('Name','Input Name')
$fk=New-Object Windows.Forms.DataGridViewComboBoxColumn
$fk.Name='Hotkey';$fk.HeaderText='Shortcut'
[void]$fk.Items.AddRange(@(
'Ctrl + Alt + Shift + F1','Ctrl + Alt + Shift + F2','Ctrl + Alt + Shift + F3',
'Ctrl + Alt + Shift + F4','Ctrl + Alt + Shift + F5','Ctrl + Alt + Shift + F6',
'Ctrl + Alt + Shift + F7','Ctrl + Alt + Shift + F8','Ctrl + Alt + Shift + F9'
))
[void]$table.Columns.Add($fk)
$f.Controls.Add($table)

$scan=New-Object Windows.Forms.Button
$scan.Text='Scan Inputs';$scan.Location=New-Object Drawing.Point(32,565);$scan.Size=New-Object Drawing.Size(126,36)
$scan.FlatStyle='Flat';$scan.BackColor=[Drawing.Color]::White
$f.Controls.Add($scan)

$hint=New-Object Windows.Forms.Label
$hint.Text='Scan the monitor to discover VCP 60 input values when available.'
$hint.ForeColor=[Drawing.Color]::FromArgb(100,108,118)
$hint.AutoSize=$true;$hint.Location=New-Object Drawing.Point(174,576)
$f.Controls.Add($hint)

$cancel=New-Object Windows.Forms.Button
$cancel.Text='Cancel';$cancel.Size=New-Object Drawing.Size(110,40);$cancel.Location=New-Object Drawing.Point(632,616)
$cancel.FlatStyle='Flat';$cancel.BackColor=[Drawing.Color]::White
$f.Controls.Add($cancel);$cancel.Add_Click({$f.Close()})

$save=New-Object Windows.Forms.Button
$save.Text='Save & Restart';$save.Size=New-Object Drawing.Size(150,40);$save.Location=New-Object Drawing.Point(722,616)
$save.FlatStyle='Flat';$save.BackColor=[Drawing.Color]::FromArgb(24,91,171)
$save.ForeColor=[Drawing.Color]::White
$f.Controls.Add($save)

$script:monitors=@()

function Invoke-MonitorScan {
    $script:monitors=@()
    $tmp=Join-Path $env:TEMP ("MonitorBuddySettings_"+[guid]::NewGuid().ToString()+'.txt')
    try {
        & $Cmm /smonitors $tmp | Out-Null
        if(Test-Path $tmp){
            $text=Get-Content -LiteralPath $tmp -Raw
            foreach($b in [regex]::Split($text.Trim(),"(?m)(?=Monitor Device Name:\s*)")){
                if($b -notmatch 'Monitor Device Name:'){continue}
                $dev=([regex]::Match($b,'Monitor Device Name:\s*"?([^"\r\n]+)"?')).Groups[1].Value.Trim()
                $name=([regex]::Match($b,'Monitor Name:\s*"?([^"\r\n]+)"?')).Groups[1].Value.Trim()
                $serial=([regex]::Match($b,'Serial Number:\s*"?([^"\r\n]+)"?')).Groups[1].Value.Trim()
                $short=([regex]::Match($b,'Short Monitor ID:\s*([^\r\n]+)')).Groups[1].Value.Trim()
                if($dev){
                    $script:monitors += [pscustomobject]@{
                        Name=$name;Device=$dev;Serial=$serial;Short=$short
                    }
                }
            }
        }
    } catch {}
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}

function Get-Profile($m){
    $key=KeyForMonitor $m
    foreach($p in @($profiles.Profiles)){
        if([string]$p.Key -eq $key){ return $p }
    }
    return $null
}

function Scan-InputValues($m){
    $tmp=Join-Path $env:TEMP ("MonitorBuddyInputs_"+[guid]::NewGuid().ToString()+'.json')
    $found=@()
    try {
        # NirSoft syntax is: /sjson <Filename> <Monitor String>
        & $Cmm /sjson $tmp $m.Device | Out-Null

        if(Test-Path $tmp){
            $raw=Get-Content -LiteralPath $tmp -Raw -Encoding UTF8
            if(-not [string]::IsNullOrWhiteSpace($raw)){
                $data=$raw | ConvertFrom-Json

                # Convert a single JSON object or an array into a predictable list.
                $items=@()
                if($data -is [System.Array]){$items=@($data)}
                else{$items=@($data)}

                foreach($x in $items){
                    # ControlMyMonitor's exported JSON column names can contain
                    # spaces. Accept both human-readable and compact variants.
                    $props=@{}
                    foreach($p in $x.PSObject.Properties){
                        $props[$p.Name.ToLowerInvariant().Replace(' ','').Replace('_','')]=[string]$p.Value
                    }

                    $code=''
                    foreach($k in @('vcpcode','code','vcp')){
                        if($props.ContainsKey($k)){$code=$props[$k];break}
                    }
                    $codeNorm=$code.Trim().ToUpperInvariant()
                    if($codeNorm -eq '60' -or $codeNorm -eq '0X60'){
                        $pv=''
                        foreach($k in @('possiblevalues','possiblevalue','possible')){
                            if($props.ContainsKey($k)){$pv=$props[$k];break}
                        }

                        # Possible Values may look like "15, 17", "15;17",
                        # "15,17" or similar. Extract numeric values safely.
                        foreach($match in [regex]::Matches($pv,'(?<!\d)(\d+)(?!\d)')){
                            $n=[int]$match.Groups[1].Value
                            if($n -ge 0 -and $n -le 255 -and $found -notcontains $n){
                                $found += $n
                            }
                        }
                    }
                }
            }
        }
    } catch {
        # Do not let a monitor with unusual export data break Settings.
    }
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue

    # Reliable fallback: ControlMyMonitor documents /GetValue as returning the
    # current VCP value through the process exit code.
    if($found.Count -eq 0){
        try {
            & $Cmm /GetValue $m.Device 60 | Out-Null
            $v=[int]$LASTEXITCODE
            if($v -ge 0 -and $v -le 255){$found=@($v)}
        } catch {}
    }

    return @($found | Sort-Object {[int]$_})
}

function Load-TableForMonitor($m){
    $table.Rows.Clear()
    $p=Get-Profile $m
    if($null -eq $p){
        $vals=Scan-InputValues $m
        foreach($v in $vals){
            $row=$table.Rows.Add()
            $table.Rows[$row].Cells[0].Value=[string]$v
            $table.Rows[$row].Cells[1].Value="Input $v"
            $table.Rows[$row].Cells[2].Value=("Ctrl + Alt + Shift + F{0}" -f ([Math]::Min(9,$row+1)))
        }
        $profileInfo.Text='New profile. Scan results loaded. Rename inputs and choose shortcuts, then save.'
    } else {
        foreach($inp in @($p.Inputs)){
            $row=$table.Rows.Add()
            $table.Rows[$row].Cells[0].Value=[string]$inp.Value
            $table.Rows[$row].Cells[1].Value=[string]$inp.Name
            $table.Rows[$row].Cells[2].Value=[string]$inp.Hotkey
        }
        $profileInfo.Text=("Profile saved for {0}. Only this selected monitor will respond to the shortcuts." -f $m.Name)
    }
}

function Populate-Monitors {
    $oldKey=''
    if($mon.SelectedIndex -ge 0 -and $mon.SelectedIndex -lt $script:monitors.Count){
        $oldKey=KeyForMonitor $script:monitors[$mon.SelectedIndex]
    }
    $mon.Items.Clear()
    foreach($m in $script:monitors){[void]$mon.Items.Add($m.Name)}
    $idx=0
    if($oldKey){
        for($i=0;$i -lt $script:monitors.Count;$i++){
            if((KeyForMonitor $script:monitors[$i]) -eq $oldKey){$idx=$i;break}
        }
    } elseif($script:monitors.Count -gt 0) {
        $selected=[string]$cfg.Monitor.String
        for($i=0;$i -lt $script:monitors.Count;$i++){
            if((KeyForMonitor $script:monitors[$i]) -eq $selected.Trim('"') -or
               $script:monitors[$i].Name -eq [string]$cfg.Monitor.Name){$idx=$i;break}
        }
    }
    if($script:monitors.Count -gt 0){
        $mon.SelectedIndex=$idx
    } else {
        $profileInfo.Text='No DDC/CI monitors detected. Check cables and DDC/CI support.'
    }
}

$refresh.Add_Click({
    $f.Cursor=[Windows.Forms.Cursors]::WaitCursor
    $profileInfo.Text='Refreshing monitor list...'
    Invoke-MonitorScan
    Populate-Monitors
    if($mon.SelectedIndex -ge 0){Load-TableForMonitor $script:monitors[$mon.SelectedIndex]}
    $f.Cursor=[Windows.Forms.Cursors]::Default
})

$mon.Add_SelectedIndexChanged({
    if($mon.SelectedIndex -ge 0 -and $mon.SelectedIndex -lt $script:monitors.Count){
        Load-TableForMonitor $script:monitors[$mon.SelectedIndex]
    }
})

$scan.Add_Click({
    if($mon.SelectedIndex -lt 0){Msg 'Select a monitor first.';return}
    $m=$script:monitors[$mon.SelectedIndex]
    $f.Cursor=[Windows.Forms.Cursors]::WaitCursor
    $profileInfo.Text="Scanning VCP 60 inputs for $($m.Name)..."
    $vals=Scan-InputValues $m
    $existing=@{}
    foreach($row in $table.Rows){
        $existing[[string]$row.Cells[0].Value]=$row
    }
    foreach($v in $vals){
        if(-not $existing.ContainsKey([string]$v)){
            $row=$table.Rows.Add()
            $table.Rows[$row].Cells[0].Value=[string]$v
            $table.Rows[$row].Cells[1].Value="Input $v"
            $next=[Math]::Min(9,$row+1)
            $table.Rows[$row].Cells[2].Value=("Ctrl + Alt + Shift + F{0}" -f $next)
        }
    }
    if($vals.Count -gt 0){$profileInfo.Text=("Found {0} input value(s) for {1}." -f $vals.Count,$m.Name)}
    else {$profileInfo.Text='The monitor did not report a Possible Values list for VCP 60. The current input is still usable; add other values manually if needed.'}
    $f.Cursor=[Windows.Forms.Cursors]::Default
})

$save.Add_Click({
    if($script:monitors.Count -eq 0 -or $mon.SelectedIndex -lt 0){Msg 'No monitor is selected.';return}
    $m=$script:monitors[$mon.SelectedIndex]
    $inputs=@()
    $used=@{}
    foreach($row in $table.Rows){
        $v=[string]$row.Cells[0].Value
        if([string]::IsNullOrWhiteSpace($v)){continue}
        $hk=[string]$row.Cells[2].Value
        if([string]::IsNullOrWhiteSpace($hk)){Msg "Every input needs a shortcut.";return}
        if($used.ContainsKey($hk)){Msg "Duplicate shortcut: $hk`nChoose a different F-key.";return}
        $used[$hk]=$true
        $inputs += [ordered]@{
            Value=[int]$v
            Name=[string]$row.Cells[1].Value
            Hotkey=$hk
        }
    }

    $key=KeyForMonitor $m
    $newProfile=[ordered]@{
        Key=$key
        Monitor=[ordered]@{
            String=$m.Short.Trim('"')
            Name=$m.Name
            Device=$m.Device
            Serial=$m.Serial
            ShortID=$m.Short.Trim('"')
        }
        VCP=60
        Inputs=$inputs
    }

    $arr=@()
    $replaced=$false
    foreach($p in @($profiles.Profiles)){
        if([string]$p.Key -eq $key){$arr+=[pscustomobject]$newProfile;$replaced=$true}
        else {$arr+=$p}
    }
    if(-not $replaced){$arr+=[pscustomobject]$newProfile}
    $profiles=[pscustomobject]@{Version=1;Profiles=$arr}
    Save-Json $profiles $ProfilesFile

    # Active config remains intentionally simple. The runtime only receives
    # the currently selected profile, so other monitor profiles are dormant.
    $out=[ordered]@{
        Version=1
        Monitor=$newProfile.Monitor
        VCP=60
        Inputs=$inputs
    }
    Save-Json $out $Cfg

    $flag=Join-Path $Root 'config\restart.flag'
    Set-Content -LiteralPath $flag -Value 'restart' -Encoding ASCII

    # Wait for the running tray instance to release its global mutex.
    # This prevents the new instance from starting too early and exiting with
    # ALREADY_RUNNING.
    $ready=$false
    for($wait=0;$wait -lt 40;$wait++){
        Start-Sleep -Milliseconds 250
        $probe=$null
        try {
            $probe=New-Object System.Threading.Mutex($false,'Global\MonitorBuddyUniversal')
            if($probe.WaitOne(0,$false)){
                $probe.ReleaseMutex() | Out-Null
                $ready=$true
                $probe.Dispose()
                break
            }
        } catch {}
        try { if($probe){$probe.Dispose()} } catch {}
    }

    if($ready){
        $appExe=Join-Path $Root 'MonitorBuddy.exe'
        if(Test-Path -LiteralPath $appExe){
            Start-Process -FilePath $appExe -WorkingDirectory $Root | Out-Null
        } else {
            Start-Process (Join-Path $Root 'Start-MonitorBuddy.bat') -WorkingDirectory $Root
        }
        Msg 'Profile saved. Monitor Buddy has restarted with the selected monitor active.'
    } else {
        Msg 'Profile saved, but Monitor Buddy did not release its previous session in time.`n`nPlease use the Monitor Buddy desktop shortcut to start it.'
    }
    $f.Close()
})

# Initial scan.
$f.Cursor=[Windows.Forms.Cursors]::WaitCursor
Invoke-MonitorScan
Populate-Monitors
if($mon.SelectedIndex -ge 0){Load-TableForMonitor $script:monitors[$mon.SelectedIndex]}
$f.Cursor=[Windows.Forms.Cursors]::Default

[void]$f.ShowDialog()

# This script is a dedicated GUI host; terminate it after the form closes.
[Environment]::Exit(0)
