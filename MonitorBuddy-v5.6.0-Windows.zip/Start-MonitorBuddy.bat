@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0MonitorBuddy.exe" (
    start "" "%~dp0MonitorBuddy.exe"
    exit /b 0
)
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0src\MonitorBuddy.ps1"
endlocal
